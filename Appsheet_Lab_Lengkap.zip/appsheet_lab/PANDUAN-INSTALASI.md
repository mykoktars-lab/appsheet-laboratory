# Panduan dari awal sampai APK terpasang

## A. Buat project Firebase
1. Buka https://console.firebase.google.com/ lalu login dengan Google.
2. Klik **Add project**; beri nama `appsheet-lab` (nama bebas), lanjutkan sampai project selesai dibuat.
3. Pada halaman project, klik ikon Web `</>` untuk mendaftarkan aplikasi web. Isi nama `Appsheet Lab`; hosting tidak wajib. Salin konfigurasi Firebase yang ditampilkan.
4. Masuk **Build → Authentication → Get started → Sign-in method**. Aktifkan **Email/Password**, lalu Save.
5. Masuk **Build → Firestore Database → Create database**. Pilih lokasi terdekat yang tersedia dan sesuai kebijakan organisasi. Mulai dalam production mode.
6. Buka tab **Rules** pada Firestore, ganti isinya dengan file `firestore.rules` dari ZIP, lalu Publish.
7. Pada Project settings → General → Your apps, salin nilai `apiKey`, `authDomain`, `projectId`, `storageBucket`, `messagingSenderId`, dan `appId`.

## B. Upload ke GitHub
1. Buat repository baru di https://github.com/new, misalnya `appsheet-lab`.
2. Ekstrak ZIP ini di komputer.
3. Upload seluruh isi folder `appsheet_lab` ke repository (pastikan folder `.github/workflows` ikut ter-upload). Cara paling mudah: GitHub Desktop atau Git dari komputer. Jika memakai web GitHub, gunakan **Add file → Upload files** dan seret semua file/folder dari hasil ekstrak.
4. Pastikan file `.github/workflows/build-apk.yml` ada. GitHub tidak selalu menampilkan folder tersembunyi di file picker; cek kembali setelah upload.

## C. Masukkan konfigurasi Firebase ke GitHub Secrets
1. Buka repository → **Settings → Secrets and variables → Actions**.
2. Klik **New repository secret** satu per satu. Nama harus persis:
   - `VITE_FIREBASE_API_KEY`
   - `VITE_FIREBASE_AUTH_DOMAIN`
   - `VITE_FIREBASE_PROJECT_ID`
   - `VITE_FIREBASE_STORAGE_BUCKET`
   - `VITE_FIREBASE_MESSAGING_SENDER_ID`
   - `VITE_FIREBASE_APP_ID`
3. Isi masing-masing dengan nilai dari Firebase. Jangan menambahkan tanda kutip.
4. Jangan pernah memasukkan service-account private key ke aplikasi Android atau repository.

## D. Build APK melalui GitHub Actions
1. Buka tab **Actions** di repository.
2. Pilih workflow **Build Appsheet Lab APK**.
3. Klik **Run workflow → Run workflow**.
4. Tunggu sampai semua langkah berwarna hijau. Build pertama dapat memerlukan beberapa menit.
5. Klik hasil workflow yang berhasil, cari bagian **Artifacts**, unduh `appsheet-lab-debug-apk`.
6. Ekstrak file ZIP artifact tersebut. Di dalamnya ada `app-debug.apk`.
7. Kirim APK ke HP Android dan instal. Jika diminta, izinkan instalasi dari sumber tersebut.

Jika workflow tidak muncul, pastikan file `.github/workflows/build-apk.yml` sudah ada di branch `main`. Jika build gagal, buka log langkah yang merah dan periksa pesan error.

## E. Siapkan pengguna laboratorium
1. Buka aplikasi dan pilih **Daftar** untuk membuat akun tiap analis.
2. Setiap orang masuk menggunakan email/password masing-masing.
3. Setelah akun terdaftar, semua akun yang login dapat melihat stok yang sama dan transaksi tersinkron melalui Firestore.
4. Tambahkan barang pertama dari menu **Barang → Tambah Barang**. Masukkan satuan yang konsisten, misalnya Aquadest = L, NaOH = kg, KOH = kg.
5. Untuk pemakaian pilih **Riwayat → Catat Transaksi → Barang keluar**. Untuk penerimaan pilih **Barang masuk**.

## F. Buat dan bagikan PDF
1. Buka menu **Laporan PDF**.
2. Isi **NO. Form** pada kolom kosong (contoh format `001/W-01/2026`; sesuaikan penomoran resmi tempat kerja).
3. Pilih tanggal laporan.
4. Klik **Buat & Bagikan PDF**. Pada Android yang mendukung Web Share API, pilih WhatsApp atau Gmail dari menu berbagi. Jika tidak, PDF akan diunduh dahulu.
5. Periksa isi PDF sebelum dikirim. Laporan menarik transaksi keluar terbaru (maksimal 100 baris) dan menyertakan waktu serta pengguna pada kolom Remark.

## G. Pengembangan lokal (opsional)
Perlu Node.js 22 dan Android Studio/Android SDK untuk build lokal.
```bash
npm install
cp .env.example .env
# Isi nilai Firebase pada .env
npm run dev
# Untuk Android:
npm run build
npx cap add android   # hanya pertama kali
npx cap sync android
npx cap open android
```

## Catatan keamanan dan operasional
- Firestore Rules dalam starter ini membatasi akses untuk pengguna login, tetapi semua pengguna login dapat menambah/mengubah data barang dan membaca transaksi. Untuk penggunaan resmi, sebaiknya tambahkan role admin/analis melalui custom claims atau dokumen role yang divalidasi Rules.
- Jangan membagikan akun bersama. Gunakan akun individual agar pelacakan pengguna benar.
- Firestore dapat menimbulkan biaya setelah kuota gratis terlampaui. Pantau Firebase Usage & billing dan tetapkan budget alert.
- Pastikan persetujuan penanggung jawab lab sebelum mengunggah data operasional, kode material, atau dokumen internal.
- Fitur share langsung bergantung dukungan Android/browser. Bila perangkat tidak mendukung berbagi file, PDF akan diunduh sebagai fallback.
- Form PDF mereplikasi susunan dan teks utama Word acuan. Tabel menggunakan riwayat transaksi aplikasi; kode SAP material belum tersedia pada data barang sehingga ditampilkan `-`. Sesuaikan bila diperlukan.
