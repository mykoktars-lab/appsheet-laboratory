# Appsheet Lab
Aplikasi inventory laboratorium berbasis React + Vite + Firebase Firestore + Capacitor Android.

## Isi fitur
- Login dan registrasi email/password Firebase.
- Data barang dengan stok, UOM, stok minimum, kategori, lokasi.
- Transaksi barang masuk/keluar yang mengubah stok secara atomik (Firestore transaction).
- Riwayat dengan timestamp dan identitas pengguna.
- Monitoring stok dan grafik.
- Pembuatan PDF mengikuti susunan Form Pemakaian Bahan Kimia yang disediakan; No. Form dapat diisi sebelum PDF dibuat.
- Menu berbagi PDF melalui Android Share Sheet (WhatsApp/Gmail jika tersedia).
- GitHub Actions untuk membangun APK debug.

## Catatan penting
Contoh bahan pada tampilan demo hanya muncul sebelum Firebase dikonfigurasi. Jangan memasukkan data operasional nyata sebelum aturan akses dan akun admin ditetapkan. File PDF disusun mengikuti struktur dokumen Word acuan; hasilnya PDF baru, bukan konversi Word pixel-perfect. SAP Material pada tabel laporan diberi tanda '-' karena kode SAP belum menjadi field wajib di data barang.
